This is a client-server program that when connected will provide you with an IT-related acronym and prompt you to answer it.
It will continue to give you acronyms until you type in quit.
As you get the acronyms correct or incorrect it will provide a score total based on how many times you have been prompted to answer.

STEPS TO RUN:
1. Start server.py
2. Start client.py
3. Enjoy