def my_info():
    name = "Gage Rotz"
    age = "20"
    color = "Blue"
    print(name)
    print(age)
    print(color)